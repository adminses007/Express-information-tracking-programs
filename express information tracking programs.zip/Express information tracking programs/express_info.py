import tkinter as tk
from tkinter import scrolledtext
from tkinter import messagebox
import sqlite3
from tkinter import font

def init_db():
    conn = sqlite3.connect('express_info.db')
    conn.execute("PRAGMA encoding = 'UTF-8'")
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS express (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tracking_number TEXT UNIQUE,
            status TEXT
        )
    ''')
    conn.commit()
    conn.close()

def add_express_info(tracking_number, status):
    conn = sqlite3.connect('express_info.db')
    cursor = conn.cursor()
    try:
        cursor.execute('INSERT INTO express (tracking_number, status) VALUES (?, ?)', (tracking_number, status))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        messagebox.showerror("Tips", "ပါဆယ်နံပါတ်ရှိထားပါပီး")
        return False
    finally:
        conn.close()

def delete_express_info(tracking_number):
    conn = sqlite3.connect('express_info.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM express WHERE tracking_number = ?', (tracking_number,))
    if cursor.rowcount == 0:
        messagebox.showwarning("Tips", "ပါဆယ်နံပါတ်မရှိပါ")
    else:
        messagebox.showinfo("Tips", "ပါဆယ်နံပါတ်ဖျက်လိုက်ပါပီ")
    conn.commit()
    conn.close()

def search_express_info(tracking_number):
    conn = sqlite3.connect('express_info.db')
    cursor = conn.cursor()
    cursor.execute('SELECT tracking_number, status FROM express WHERE tracking_number = ?', (tracking_number,))
    result = cursor.fetchone()
    conn.close()
    if result:
        messagebox.showinfo("Results", f"Tracking Number: {result[0]}, Status: {result[1]}")
    else:
        messagebox.showerror("Tips", "ပါဆယ်နံပါတ်မရှိပါ")
def update_express_info(tracking_number, new_status):
    conn = sqlite3.connect('express_info.db')
    cursor = conn.cursor()
    cursor.execute('UPDATE express SET status = ? WHERE tracking_number = ?', (new_status, tracking_number))
    if cursor.rowcount == 0:
        messagebox.showwarning("Tips", "ပါဆယ်နံပါတ်မရှိပါ")
    else:
        messagebox.showinfo("Tips", "Statusချိန်းပီးပါပီ")
    conn.commit()
    conn.close()

def add_info():
    tracking_number = entry_tracking_number.get()
    status = entry_status.get()
    if tracking_number and status:
        if add_express_info(tracking_number, status):
            text_area.config(state=tk.NORMAL)
            text_area.insert(tk.END, f"Tracking Number: {tracking_number}, Status: {status}\n")
            text_area.config(state=tk.DISABLED)
        entry_tracking_number.delete(0, tk.END)
        entry_status.delete(0, tk.END)
    else:
        messagebox.showwarning("Tips", "ပါဆယ်နံပါတ်ကို ရိုက်ထည့်ပါ။。")

def delete_info():
    tracking_number = entry_tracking_number.get()
    if tracking_number:
        delete_express_info(tracking_number)
        entry_tracking_number.delete(0, tk.END)
        entry_status.delete(0, tk.END)
    else:
        messagebox.showwarning("Tips", "သင်ဖျက်လိုသည့် ပါဆယ်နံပါတ်ကို ရိုက်ထည့်ပါ။")
    refresh_text_area()

def search_info():
    tracking_number = entry_tracking_number.get()
    if tracking_number:
        search_express_info(tracking_number)
        entry_tracking_number.delete(0, tk.END)
    else:
        messagebox.showwarning("Tips", "သင်ရှာလိုသည့် ပါဆယ်နံပါတ်ကို ရိုက်ထည့်ပါ။")

def refresh_text_area():
    text_area.config(state=tk.NORMAL)
    text_area.delete('1.0', tk.END)
    conn = sqlite3.connect('express_info.db')
    cursor = conn.cursor()
    cursor.execute('SELECT tracking_number, status FROM express')
    for row in cursor.fetchall():
        text_area.insert(tk.END, f"Tracking number: **{row[0]}** >>> Status: **{row[1]}**\n")
    conn.close()
    text_area.config(state=tk.DISABLED)

def modify_info():
    tracking_number = entry_tracking_number.get()
    new_status = entry_status.get()
    if tracking_number and new_status:
        update_express_info(tracking_number, new_status)
        entry_tracking_number.delete(0, tk.END)
        entry_status.delete(0, tk.END)
    else:
        messagebox.showwarning("Tips", "ပါဆယ်နံပါတ်နှင့် Statusကို ရိုက်ထည့်ပါ")
    refresh_text_area()

init_db()

root = tk.Tk()
root.title("Express Information System")
#root.iconbitmap('express_ico.ico')
myanmar_font = font.Font(family="Pyidaungsu", size=12)

root.configure(bg="#ADD8E6")

screen_width = 650
screen_height = 800
root.geometry("{}x{}+{}+{}".format(screen_width, screen_height,
                                   (root.winfo_screenwidth() - screen_width) // 2,
                                   (root.winfo_screenheight() - screen_height) // 2))
root.resizable(False,False)

burmese_font = ("Pyidaungsu", 12)


frame = tk.Frame(root,bg="#ADD8E6")
frame.pack(padx=10, pady=10)

label_tracking_number = tk.Label(frame, text="Tracking No:",highlightbackground="orange", highlightcolor="orange",bg="#ADD8E6")
label_tracking_number.pack(side=tk.LEFT)
entry_tracking_number = tk.Entry(frame,highlightbackground="orange", highlightcolor="orange",bg="#ADD8E6")
entry_tracking_number.pack(side=tk.LEFT)

label_status = tk.Label(frame, text="Status:",highlightbackground="orange", highlightcolor="orange",bg="#ADD8E6")
label_status.pack(side=tk.LEFT)
entry_status = tk.Entry(frame,highlightbackground="orange", highlightcolor="orange",bg="#ADD8E6")
entry_status.pack(side=tk.LEFT)

frame_buttons = tk.Frame(root, bg="#ADD8E6")
frame_buttons.pack(pady=10)

button_add = tk.Button(frame_buttons, text="Add", command=add_info,highlightbackground="orange", highlightcolor="orange",bg="#ADD8E6")
button_add.pack(side=tk.LEFT, padx=5)

button_delete = tk.Button(frame_buttons, text="Delete", command=delete_info,highlightbackground="orange", highlightcolor="orange",bg="#ADD8E6")
button_delete.pack(side=tk.LEFT, padx=5)

button_search = tk.Button(frame_buttons, text="Search", command=search_info,highlightbackground="orange", highlightcolor="orange",bg="#ADD8E6")
button_search.pack(side=tk.LEFT, padx=5)

button_modify = tk.Button(frame_buttons, text="Modify", command=modify_info,highlightbackground="orange", highlightcolor="orange",bg="#ADD8E6")
button_modify.pack(side=tk.LEFT, padx=5)

text_area = scrolledtext.ScrolledText(root, width=80, height=50,bg="#ADD8E6")
text_area.pack(padx=10, pady=5)
text_area.config(state=tk.DISABLED)

refresh_text_area()

root.mainloop()
